package com.example.tugas_submission2_bfaa.Datamodel

data class UserSearchDatamodel(
    val items: ArrayList<UserDatamodel>
)