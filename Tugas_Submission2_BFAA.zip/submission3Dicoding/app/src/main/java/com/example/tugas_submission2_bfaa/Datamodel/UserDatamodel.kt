package com.example.tugas_submission2_bfaa.Datamodel

data class UserDatamodel(

    val login: String,
    val id: Int,
    val avatar_url: String,
    val type: String,
)